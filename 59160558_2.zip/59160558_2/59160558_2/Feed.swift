//
//  Feed.swift
//  59160558_2
//
//  Created by student on 8/5/2562 BE.
//  Copyright © 2562 wasin. All rights reserved.
//

import UIKit

class Feed: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

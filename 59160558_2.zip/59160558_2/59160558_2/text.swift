//
//  text.swift
//  59160558_2
//
//  Created by student on 8/5/2562 BE.
//  Copyright © 2562 wasin. All rights reserved.
//

import UIKit

class text: UITableViewCell {

    
}
